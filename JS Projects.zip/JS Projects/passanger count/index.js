// let myage= 2
// let humandogration=7

// let mydogage = myage*humandogration
// console.log(mydogage)

// let bonusPoints = 50

// bonusPoints =bonusPoints+100
// console.log(bonusPoints)
// bonusPoints= bonusPoints-25
// console.log(bonusPoints)
// bonusPoints= bonusPoints=75

// console.log(bonusPoints)

// function incremental()
// {
//     window.alert("the button is clicked")
// }

// function display(){
//     console.log("45")
// }

// display()


// let lapCompleted=0

// function totl(){
//     lapCompleted=lapCompleted+1
     

// }
// totl()
// totl()
// totl()
// console.log(lapCompleted)


let glocount =0

function incremental(){
    glocount=glocount+1
    document.getElementById("count-el").innerText=glocount
    console.log("one person entered")
}

function save(){
    let count=0
    document.getElementById("count-el").innerText=count
    let savetext =document.getElementById("save-el")
    let con= glocount +" - "
    savetext.textContent += con
}

//  let names="maha"
//  let greetings ="hello my love"

// let disp= greetings+","+names+"."

// console.log(disp)

// function join(){
//     let jo= names +" "+ greetings +"!"
//     console.log(jo)
// }

// join()