let num1=8
let num2=9
document.getElementById("num1").textContent=num1
document.getElementById("num2").textContent=num2
let sum=document.getElementById("sum")

function add(){
    let adds=num1+num2
    sum.textContent=adds
}
function sub(){
    let ss=num1-num2
    sum.textContent=ss
}
function mul(){
    let mul=num1*num2
    sum.textContent=mul
}
function dd(){
    let dds=num1/num2
    sum.textContent=dds
}

