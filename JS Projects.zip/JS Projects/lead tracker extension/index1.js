

const r="maha"
let sender="james"

const emai=`hey ${r}! 
    how's it going? 
cheers ${sender}`

//console.log(emai)

x=0
console.log(typeof x)