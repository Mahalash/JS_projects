let myLeads=[]
const inputEl= document.getElementById("input-el")

const button_event= document.getElementById("input-btn")
const unorder_list=document.getElementById("ul-el")
const delete_event=document.getElementById("del")
const save_event=document.getElementById("save-btn")

const leadsFromLocalStroage=JSON.parse(localStorage.getItem(("myLeads")))
if (leadsFromLocalStroage){
    myLeads=leadsFromLocalStroage
    render(myLeads)
}

save_event.addEventListener("click", function(){    
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs){
        myLeads.push(tabs[0].url)
        localStorage.setItem("myLeads", JSON.stringify(myLeads) )
        render(myLeads)
    })

    
})

function render(leads){
    listItems=""
    for(let i=0;i < leads.length;i++){
        listItems += `
        <li>
            <a target='_ blank' href='${myLeads[i]}'> ${myLeads[i]}</a>
        </li>`
    //     const li= document.createElement("li")
    //     li.textContent= myLeads[i]
    //     unorder_list.append(li)
           
    //
     }
     unorder_list.innerHTML=listItems
    }
button_event.addEventListener("click",function(){
    myLeads.push(inputEl.value)
    inputEl.value = ""
   
    localStorage.setItem("myLeads",JSON.stringify(myLeads))
    render(myLeads)
    console.log(localStorage.getItem("myLeads"))
})

delete_event.addEventListener("dblclick",function(){
    localStorage.clear()
    myLeads =[]
    render(myLeads)
})


