const movies = [
    "Kadhalai Thavire Verondrum Illai",
    "Tharkappu",
    "Aindhaam Thalaimurai Sidha Vaidhiya Sigamani",
    "Meenakshi Kadhalan Ilangovan",
    "Thigilodu Vilaiyaadu",
    "Mudhal Thagaval Arikkai",
    "Yokkiyan Varan Somba Thooki Ulla Vai",
    "Kanden Kadhal Konden",
    "Kallathoni",
    "Kuttrame Thandanai",
    "Pachaikili Parimala",
    "Amara Kaaviyam",
    "Mupparimanam"
]


            let players = [];
            let scores = {};
            let currentIndex = 0;

            document.getElementById("playersForm").addEventListener("submit", function (event) {
                event.preventDefault();
                const playersInput = document.getElementById("players").value;
                players = playersInput.split(",").map(player => player.trim()).filter(player => player);
                console.log(players)
                if (players.length > 0) {
                    players.forEach(player => scores[player] = 0);
                    document.getElementById("output").innerHTML = "";
                    document.getElementById("gameSection").style.display = "block";
                    assignMovie();
                } else {
                    document.getElementById("output").innerHTML = "<p>Please enter valid player names separated by commas.</p>";
                }
            });

            function assignMovie() {
                const currentPlayer = players[currentIndex];
                console.log(currentPlayer)
                const randomMovie = movies[Math.floor(Math.random() * movies.length)];
                document.getElementById("currentPlayer").textContent = `Current Player: ${currentPlayer}`;
                document.getElementById("assignedMovie").textContent = `Assigned Movie: ${randomMovie}`;
            }
            document.getElementById("markResult").addEventListener("click", function () {
                const result = document.getElementById("result").value;
                const currentPlayer = players[currentIndex];
                if (result === "succeed") {
                    scores[currentPlayer]++;
                    alert(`${currentPlayer} succeeded!`);
                } else if (result === "fail") {
                    alert(`${currentPlayer} failed!`);
                } else {
                    alert("Please select a result before submitting.");
                    return;
                }
            });

            document.getElementById("nextPlayer").addEventListener("click", function () {
                const currentPlayer = players[currentIndex];
                
                currentIndex = (currentIndex + 1) % players.length;
                assignMovie();
            });

            document.getElementById("viewResults").addEventListener("click", function () {
                const resultList = document.getElementById("results");
                resultList.innerHTML = "";
                for (const [player, score] of Object.entries(scores)) {
                    const listItem = document.createElement("li");
                    listItem.textContent = `${player}: ${score} points`;
                    resultList.appendChild(listItem);
                }
                document.getElementById("resultBoard").style.display = "block";
            });
      