// let rant= Math.floor(89.324234)

// console.log(rant)

// function rolldice(){
//     return Math.floor(Math.random()*6)+1
// }

// let one=rolldice()
// console.log(one)

// let castle={
//     name:"tipu sultan palace",
//     guests_no: 4,
//     bedrooms:2,
//     beds:3,
//     baths:["privatehalf","bath","swimmingpool"],
//     rate:190,
//     is_superHost:true,
// }

// console.log(castle.beds)

// let myself={
//     name:"maha",
//     age: 20,
//     lives:"chennai"
// }
// function logData(){
//     let sentence= myself.name +" is " +myself.age+" years old and lives in "+myself.lives
//     console.log(sentence)
// }

// logData()

let largecountries=["India","Pakistan","Afganistan","Korea"]
console.log("the largest countries are: ")
for(i=0;i<largecountries.length;i++){
   
    console.log("- "+ largecountries[i])
    
}