
let card_arr=[]
let sum = 0
let hasBlackJack = false
let isalive=false
let message= " "
let player={name:"Maha",credits:145}

let messageEl= document.getElementById("message-el")
let total= document.getElementById("sum") 
let cards=document.querySelector("#card")
let cer=document.getElementById("credit")
    cer.textContent= player.name +": $"+player.credits
function randomcard(){
    let rant= Math.floor(Math.random()*13)+1
    if (rant==1) {
        return 11
    }else if (rant==[10,11,12]){
        return 10
    }else{
        return rant
    }
}

function startgame(){
    let firstCard = randomcard()
    let secondCard = randomcard()
    isalive=true
    card_arr.push(firstCard,secondCard)
    sum=firstCard+secondCard
    rendergame()
}

function rendergame(){
total.textContent="Sum:"+sum.toString()
cards.textContent="cards:"
for(let i=0;i<card_arr.length;i++){
    cards.textContent += card_arr[i] + " "
}
if (sum <= 20) {
    message = "Do you want to draw a new card? "
} else if (sum === 21) {
    message = "Wohoo! You've got Blackjack! "
    hasBlackJack = true
} else {
    message = "You're out of the game! "
    isalive=false
}

messageEl.textContent=message
}

console.log(message)

function news(){
    if(isalive==true && hasBlackJack==false){
console.log("new card selection")
let new_card=randomcard()
sum += new_card
card_arr.push(new_card)

rendergame()
    }
}

